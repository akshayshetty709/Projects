const express = require('express');
const cors = require('cors');
const client = require('prom-client');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5003;
const PAYMENT_SERVICE_URL = process.env.PAYMENT_SERVICE_URL || 'http://payment-service:5004';

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpRequestCounter = new client.Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'route', 'status']
});
register.registerMetric(httpRequestCounter);
app.use((req, res, next) => {
  res.on('finish', () => httpRequestCounter.inc({ method: req.method, route: req.path, status: res.statusCode }));
  next();
});
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'order-service' }));

let orders = [];
let orderIdCounter = 1;

app.get('/orders', (req, res) => res.json(orders));

app.get('/orders/:id', (req, res) => {
  const order = orders.find(o => o.id === parseInt(req.params.id));
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

// Place order -> calls payment-service to process payment
app.post('/orders', async (req, res) => {
  const { userId, items, totalAmount, paymentMethod } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: 'Order must have items' });

  const order = {
    id: orderIdCounter++,
    userId,
    items,
    totalAmount,
    status: 'PENDING',
    createdAt: new Date().toISOString()
  };
  orders.push(order);

  try {
    const { data: payment } = await axios.post(`${PAYMENT_SERVICE_URL}/pay`, {
      orderId: order.id,
      amount: totalAmount,
      method: paymentMethod || 'CARD'
    });
    order.status = payment.status === 'SUCCESS' ? 'CONFIRMED' : 'PAYMENT_FAILED';
    order.paymentId = payment.paymentId;
  } catch (err) {
    order.status = 'PAYMENT_ERROR';
  }

  res.status(201).json(order);
});

app.listen(PORT, () => console.log(`order-service running on port ${PORT}`));
