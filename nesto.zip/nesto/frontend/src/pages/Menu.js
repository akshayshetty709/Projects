import React, { useEffect, useState } from 'react';
import { menuApi } from '../api/client';

export default function Menu() {
  const [menu, setMenu] = useState({});

  useEffect(() => {
    menuApi.get('/menu').then(res => setMenu(res.data)).catch(console.error);
  }, []);

  return (
    <div>
      <h1>Nesto — Menu</h1>
      {Object.entries(menu).map(([category, items]) => (
        <div key={category}>
          <h2>{category}</h2>
          <ul>
            {items.map(item => (
              <li key={item.id}>{item.name} — ₹{item.price}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
