import axios from 'axios';

// Point these to your API Gateway / Ingress in production
export const menuApi = axios.create({ baseURL: process.env.REACT_APP_MENU_API || 'http://localhost:5002' });
export const orderApi = axios.create({ baseURL: process.env.REACT_APP_ORDER_API || 'http://localhost:5003' });
export const userApi = axios.create({ baseURL: process.env.REACT_APP_USER_API || 'http://localhost:5005' });
