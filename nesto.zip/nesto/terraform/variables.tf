variable "aws_region" {
  default = "ap-south-1"
}

variable "cluster_name" {
  default = "nesto-eks"
}

variable "cluster_version" {
  default = "1.30"
}

variable "node_instance_type" {
  default = "c7i-flex.large"
}
