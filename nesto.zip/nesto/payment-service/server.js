const express = require('express');
const cors = require('cors');
const client = require('prom-client');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5004;

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpRequestCounter = new client.Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'route', 'status']
});
register.registerMetric(httpRequestCounter);
app.use((req, res, next) => {
  res.on('finish', () => httpRequestCounter.inc({ method: req.method, route: req.path, status: res.statusCode }));
  next();
});
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'payment-service' }));

let payments = [];
let paymentIdCounter = 1;

// Mock payment gateway — replace with Razorpay/Stripe test mode later
app.post('/pay', (req, res) => {
  const { orderId, amount, method } = req.body;
  const success = Math.random() > 0.1; // 90% success rate mock

  const payment = {
    paymentId: paymentIdCounter++,
    orderId,
    amount,
    method,
    status: success ? 'SUCCESS' : 'FAILED',
    processedAt: new Date().toISOString()
  };
  payments.push(payment);
  res.json(payment);
});

app.get('/payments/:id', (req, res) => {
  const p = payments.find(p => p.paymentId === parseInt(req.params.id));
  if (!p) return res.status(404).json({ error: 'Payment not found' });
  res.json(p);
});

app.listen(PORT, () => console.log(`payment-service running on port ${PORT}`));
