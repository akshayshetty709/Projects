# Nesto

Multi-category marketplace app (grocery + fashion) — DevOps portfolio project.

## Architecture — 5 Microservices
| Service | Port | Responsibility |
|---|---|---|
| product-service | 5001 | Product catalog, categories (vegetable, non-veg, fruits, mens-tshirt, jeans) |
| menu-service | 5002 | Aggregates products into browsable menu |
| order-service | 5003 | Cart + order placement, calls payment-service |
| payment-service | 5004 | Mock payment processing |
| user-service | 5005 | Auth (signup/login, JWT) |

Frontend: React SPA (`/frontend`)

## Local dev
```bash
docker-compose up --build
```

## Monitoring
Each service exposes `/metrics` (Prometheus format). Prometheus + Grafana manifests in `k8s/monitoring.yaml`.

## Deploy to EKS
```bash
cd terraform && terraform init && terraform apply
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/
```

## CI/CD
Jenkinsfile: Checkout -> Test -> Build & Push (Docker Hub) -> Deploy (EKS)
