const express = require('express');
const cors = require('cors');
const client = require('prom-client');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5001;

// ---- Prometheus metrics ----
const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpRequestCounter = new client.Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'route', 'status']
});
register.registerMetric(httpRequestCounter);

app.use((req, res, next) => {
  res.on('finish', () => {
    httpRequestCounter.inc({ method: req.method, route: req.path, status: res.statusCode });
  });
  next();
});

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// ---- In-memory mock data (replace with MongoDB later) ----
const categories = ['vegetable', 'non-veg', 'fruits', 'mens-tshirt', 'jeans'];
let products = [
  { id: 1, name: 'Tomato', category: 'vegetable', price: 30, stock: 100 },
  { id: 2, name: 'Chicken Breast', category: 'non-veg', price: 220, stock: 50 },
  { id: 3, name: 'Apple', category: 'fruits', price: 150, stock: 80 },
  { id: 4, name: 'Round Neck Tee', category: 'mens-tshirt', price: 499, stock: 40 },
  { id: 5, name: 'Slim Fit Jeans', category: 'jeans', price: 1299, stock: 25 }
];

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'product-service' }));

app.get('/categories', (req, res) => res.json(categories));

app.get('/products', (req, res) => {
  const { category } = req.query;
  const result = category ? products.filter(p => p.category === category) : products;
  res.json(result);
});

app.get('/products/:id', (req, res) => {
  const p = products.find(p => p.id === parseInt(req.params.id));
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});

app.post('/products', (req, res) => {
  const newProduct = { id: products.length + 1, ...req.body };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

app.listen(PORT, () => console.log(`product-service running on port ${PORT}`));
