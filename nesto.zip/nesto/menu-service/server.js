const express = require('express');
const cors = require('cors');
const client = require('prom-client');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5002;
const PRODUCT_SERVICE_URL = process.env.PRODUCT_SERVICE_URL || 'http://product-service:5001';

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpRequestCounter = new client.Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'route', 'status']
});
register.registerMetric(httpRequestCounter);
app.use((req, res, next) => {
  res.on('finish', () => httpRequestCounter.inc({ method: req.method, route: req.path, status: res.statusCode }));
  next();
});
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'menu-service' }));

// Menu = products grouped by category, fetched from product-service
app.get('/menu', async (req, res) => {
  try {
    const { data: products } = await axios.get(`${PRODUCT_SERVICE_URL}/products`);
    const menu = {};
    products.forEach(p => {
      if (!menu[p.category]) menu[p.category] = [];
      menu[p.category].push(p);
    });
    res.json(menu);
  } catch (err) {
    res.status(502).json({ error: 'product-service unavailable', details: err.message });
  }
});

app.listen(PORT, () => console.log(`menu-service running on port ${PORT}`));
