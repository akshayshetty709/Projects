# 🛒 E-Commerce Microservices — DevOps Practice Project

A complete, runnable e-commerce backend built as **6 microservices**, each
with its own database, wired together with **Docker Compose** for local dev
and **Kubernetes** for production-style deployment, plus a **GitHub Actions**
CI/CD pipeline. It includes a **realtime order-tracking** feature so you can
see events flow through the whole system live.

This is a learning project — the code is intentionally simple and heavily
commented so you understand *why*, not just *what*.

---

## 1. Architecture

```
                     ┌─────────────┐
        Browser ───▶ │ API Gateway │  (single entry point, port 4000)
                     └──────┬──────┘
        ┌───────────┬───────┼───────────┬──────────────┐
        ▼           ▼       ▼           ▼              ▼
  user-service product-service cart-service order-service  notification-service
   (Postgres)   (MongoDB)      (Redis)   (Postgres)         (WebSocket)
                                              │                   ▲
                                              └──── Redis pub/sub ┘
```

Each service:
- Owns **its own database** (a core microservices rule — no service reaches
  into another's tables directly; they only talk over HTTP or events).
- Is independently deployable, scalable, and replaceable.
- Has a `/health` endpoint for readiness/liveness checks.

### Why microservices instead of one big app?
- **Independent scaling** — Product browsing gets 100x more traffic than
  checkout; you can run 10 product-service pods and 2 order-service pods.
- **Independent deployment** — ship a cart-service fix without redeploying
  the whole app.
- **Fault isolation** — if notification-service crashes, people can still
  buy things; only realtime badges stop updating.
- **Team ownership** — in a real company, different teams own different
  services and databases.

---

## 2. Why each database? (the part most tutorials skip)

| Service | Database | Why this one, specifically |
|---|---|---|
| **user-service** | **PostgreSQL** | Users are structured, relational data. You need ACID guarantees (a signup either fully succeeds or fully fails) and will eventually join against addresses, payment methods, roles — relational DBs are built for that. |
| **product-service** | **MongoDB** | Product catalogs have *wildly different attributes per category* — a T-shirt has size/color, a laptop has RAM/CPU. Forcing that into fixed SQL columns means constant schema migrations. MongoDB's flexible documents (`attributes: {}` field in this project) absorb that variability without any migration. |
| **cart-service** | **Redis** | A cart is temporary, hit on almost every click, and doesn't need joins or complex queries. Redis lives in memory, so reads/writes are sub-millisecond, and we set a TTL so abandoned carts auto-delete after 7 days — no cleanup job needed. |
| **order-service** | **PostgreSQL** | Orders involve **money and inventory**. Placing an order must be atomic: the order row and its line items are written in a single DB transaction (`BEGIN`/`COMMIT`/`ROLLBACK` in `order-service/index.js`) so you never end up with a half-created order. This is exactly what relational databases are for. |
| **notification-service** | *(no database)* | It has no state of its own — it only relays live events. It reuses Redis, but as a **message channel** (pub/sub), not as storage. |

**The pattern to remember:** choose the database based on the *shape and
guarantees your data needs*, not "what we used last time."
- Need transactions / relationships / money? → **PostgreSQL / SQL**
- Need flexible, evolving schema, read-heavy? → **MongoDB / NoSQL**
- Need speed, temporary data, or pub/sub messaging? → **Redis**

---

## 3. How realtime works (order tracking)

1. Browser opens a WebSocket to `notification-service` and calls `socket.emit('join', userId)`.
2. `order-service` creates/updates an order, then runs `redis.publish('order_events', {...})`.
3. `notification-service` is subscribed to that Redis channel. The instant a message arrives, it does `io.to('user:'+userId).emit('order_update', event)`.
4. The browser receives the event **with no polling, no refresh** — this is
   the same pattern Uber/DoorDash/Amazon use for live order tracking.

Try it: open `frontend/index.html` after starting everything (see below),
click "Place order", then "Mark packed/shipped/delivered" and watch the log
update instantly.

---

## 4. Run it locally (Docker Compose) — start here

**Prerequisites:** Docker + Docker Compose installed.

```bash
cd ecommerce-microservices
docker compose up --build
```

This builds all 6 services and starts 4 databases. Wait ~30 seconds for
health checks to pass, then:

```bash
# Register a user
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Ada","email":"ada@example.com","password":"secret123"}'

# List products (already seeded with 4 sample products)
curl http://localhost:4000/api/products

# Add something to cart
curl -X POST http://localhost:4000/api/cart/1/items \
  -H "Content-Type: application/json" \
  -d '{"productId":"demo","name":"Mouse","price":19.99,"quantity":2}'
```

Then open `frontend/index.html` directly in your browser (double-click it,
or `python3 -m http.server` inside `frontend/`) to see realtime order events.

To stop: `docker compose down` (add `-v` to also wipe database volumes).

---

## 5. Deploy to Kubernetes (production-style)

**Prerequisites:** a cluster (minikube, kind, or a cloud one) + `kubectl`.

### Step 1 — Build & push images
```bash
# Repeat for each service (api-gateway, user-service, product-service,
# cart-service, order-service, notification-service)
docker build -t YOUR_DOCKERHUB_USER/user-service:latest ./services/user-service
docker push YOUR_DOCKERHUB_USER/user-service:latest
```
Then edit each `k8s/*-service.yaml` file and replace
`your-dockerhub-user` with your actual registry username.

### Step 2 — Apply manifests in order
```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secrets.yaml
kubectl apply -f k8s/databases.yaml
kubectl apply -f k8s/user-service.yaml
kubectl apply -f k8s/product-service.yaml
kubectl apply -f k8s/cart-service.yaml
kubectl apply -f k8s/order-service.yaml
kubectl apply -f k8s/notification-service.yaml
kubectl apply -f k8s/api-gateway.yaml
kubectl apply -f k8s/ingress.yaml
```

### Step 3 — Verify
```bash
kubectl -n ecommerce get pods         # everything should be Running
kubectl -n ecommerce get svc
kubectl -n ecommerce logs -f deployment/order-service
```

### Step 4 — Access it
```bash
kubectl -n ecommerce port-forward svc/api-gateway 4000:4000
# then curl http://localhost:4000/health
```
Or, if you have an ingress controller (e.g. `ingress-nginx`) installed, add
`127.0.0.1 shop.local` to `/etc/hosts` and browse to `http://shop.local`.

**Why this order matters:** databases must exist before app services (they
depend on them), and configmap/secrets must exist before any deployment that
references them — this is standard "infra before app" sequencing used in
real deployments.

---

## 6. CI/CD Pipeline (`.github/workflows/ci-cd.yaml`)

On every push to `main`:
1. **Test** — installs deps and syntax-checks each service independently.
2. **Build & Push** — builds a Docker image per service and pushes to
   Docker Hub, tagged with both `latest` and the git commit SHA (so you can
   always trace a running image back to exact source code — a real-company
   requirement for audits/rollbacks).
3. **Deploy** — applies Kubernetes manifests, then does a rolling update
   (`kubectl set image`) so pods update with zero downtime.

To use this yourself, add these repo secrets in GitHub:
`DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, `KUBE_CONFIG` (base64-encoded
kubeconfig for your cluster).

### Alternative: Jenkins (`Jenkinsfile`)
If your company/team uses Jenkins instead of GitHub Actions, use the
included `Jenkinsfile` — it runs the exact same 3 stages (Test → Build &
Push → Deploy) as declarative pipeline `stages{}` blocks instead of GitHub
Actions jobs:
- **Test services** — runs `npm install` + `node --check` for all 6
  services **in parallel** (`parallel` step) instead of a matrix build.
- **Build & Push images** — only runs on the `main` branch; builds and
  pushes each service's image tagged with both the Jenkins `GIT_COMMIT`
  short SHA and `latest`.
- **Deploy to Kubernetes** — gated behind a `DEPLOY` build parameter so you
  don't accidentally deploy from every merge; applies manifests then does
  a rolling `kubectl set image` update, same as the GitHub Actions version.

Before running it, set up in Jenkins:
- Credentials: `dockerhub-creds` (username/password) and `kubeconfig-creds`
  (secret file containing your kubeconfig).
- Global Tool: an NodeJS installation named `node20` (Manage Jenkins →
  Tools → NodeJS installations).
- Plugins: Docker Pipeline, Kubernetes CLI (or `kubectl` on the agent PATH).

Then create a **Pipeline job** (or Multibranch Pipeline) pointing at this
repo with "Script Path" = `Jenkinsfile`.

---

## 7. Project structure
```
ecommerce-microservices/
├── docker-compose.yml          # local orchestration
├── services/
│   ├── api-gateway/             # single entry point, routes to all services
│   ├── user-service/            # PostgreSQL — auth & profile
│   ├── product-service/         # MongoDB — catalog
│   ├── cart-service/             # Redis — shopping cart
│   ├── order-service/           # PostgreSQL + Redis pub/sub — checkout
│   └── notification-service/    # WebSocket + Redis sub — realtime push
├── k8s/                          # Kubernetes manifests for production deploy
├── .github/workflows/ci-cd.yaml # CI/CD pipeline
├── frontend/index.html          # tiny demo UI for realtime tracking
└── docs/                         # deeper explanations
```

## 8. Suggested learning path
1. Run it with Docker Compose. Read each `index.js` top to bottom — every
   file has comments explaining *why*, not just *what*.
2. Break things on purpose: stop `order-db` mid-run and watch order-service
   retry-connect logic in the logs.
3. Add a field to a product (`attributes.material`) with zero migration —
   notice you can't do that so easily in the SQL services.
4. Move to Kubernetes once comfortable. Try scaling: `kubectl -n ecommerce
   scale deployment/product-service --replicas=5`.
5. Read `docs/database-design.md` and `docs/deployment-guide.md` for deeper
   dives.
