const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4002;

// Product catalogs have VARIABLE attributes: a t-shirt has size/color,
// a laptop has RAM/CPU, a book has author/ISBN. Forcing that into rigid
// SQL columns means constant migrations. MongoDB's flexible documents
// let each product store whatever attributes it needs -> this is why
// Product Service uses MongoDB instead of PostgreSQL.
const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  category: String,
  stock: { type: Number, default: 0 },
  attributes: { type: Object, default: {} }, // flexible, per-category fields
  imageUrl: String,
  createdAt: { type: Date, default: Date.now }
});

const Product = mongoose.model('Product', productSchema);

async function connectWithRetry(retries = 10) {
  const uri = process.env.MONGO_URI || 'mongodb://product-db:27017/products_db';
  while (retries > 0) {
    try {
      await mongoose.connect(uri);
      console.log('[product-service] Mongo connected');
      return;
    } catch (err) {
      console.log('[product-service] Mongo not ready, retrying...', err.message);
      retries--;
      await new Promise(r => setTimeout(r, 3000));
    }
  }
  throw new Error('Could not connect to Mongo');
}

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'product-service' }));

app.get('/products', async (req, res) => {
  const { category, search } = req.query;
  const filter = {};
  if (category) filter.category = category;
  if (search) filter.name = { $regex: search, $options: 'i' };
  const products = await Product.find(filter).limit(100);
  res.json(products);
});

app.get('/products/:id', async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.status(404).json({ error: 'not found' });
  res.json(product);
});

app.post('/products', async (req, res) => {
  const product = new Product(req.body);
  await product.save();
  res.status(201).json(product);
});

// Used by order-service to atomically decrement stock
app.post('/products/:id/reserve', async (req, res) => {
  const { quantity } = req.body;
  const product = await Product.findOneAndUpdate(
    { _id: req.params.id, stock: { $gte: quantity } },
    { $inc: { stock: -quantity } },
    { new: true }
  );
  if (!product) return res.status(409).json({ error: 'insufficient stock' });
  res.json(product);
});

async function seedIfEmpty() {
  const count = await Product.countDocuments();
  if (count === 0) {
    await Product.insertMany([
      { name: 'Wireless Mouse', price: 19.99, category: 'electronics', stock: 50, attributes: { color: 'black', wireless: true } },
      { name: 'Mechanical Keyboard', price: 79.99, category: 'electronics', stock: 30, attributes: { switchType: 'blue' } },
      { name: 'Cotton T-Shirt', price: 14.99, category: 'apparel', stock: 100, attributes: { size: 'M', color: 'white' } },
      { name: 'Running Shoes', price: 59.99, category: 'apparel', stock: 40, attributes: { size: 42 } }
    ]);
    console.log('[product-service] seeded sample products');
  }
}

connectWithRetry().then(async () => {
  await seedIfEmpty();
  app.listen(PORT, () => console.log(`[product-service] listening on ${PORT}`));
});
