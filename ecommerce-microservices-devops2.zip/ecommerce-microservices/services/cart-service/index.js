const express = require('express');
const { createClient } = require('redis');

const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4003;

// A shopping cart is temporary, read/written constantly (every "add to
// cart" click), and doesn't need complex relationships or joins.
// Redis keeps it all in memory -> sub-millisecond reads/writes, and we
// can set a TTL so abandoned carts auto-expire. This is why Cart
// Service uses Redis instead of a relational or document DB.
const client = createClient({ url: process.env.REDIS_URL || 'redis://cart-db:6379' });
client.on('error', (err) => console.log('[cart-service] Redis error', err));

const CART_TTL_SECONDS = 60 * 60 * 24 * 7; // abandoned carts expire after 7 days

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'cart-service' }));

app.get('/cart/:userId', async (req, res) => {
  const raw = await client.get(`cart:${req.params.userId}`);
  res.json(raw ? JSON.parse(raw) : { items: [] });
});

app.post('/cart/:userId/items', async (req, res) => {
  const { productId, name, price, quantity } = req.body;
  const key = `cart:${req.params.userId}`;
  const raw = await client.get(key);
  const cart = raw ? JSON.parse(raw) : { items: [] };

  const existing = cart.items.find(i => i.productId === productId);
  if (existing) existing.quantity += quantity || 1;
  else cart.items.push({ productId, name, price, quantity: quantity || 1 });

  await client.set(key, JSON.stringify(cart), { EX: CART_TTL_SECONDS });
  res.json(cart);
});

app.delete('/cart/:userId/items/:productId', async (req, res) => {
  const key = `cart:${req.params.userId}`;
  const raw = await client.get(key);
  if (!raw) return res.json({ items: [] });
  const cart = JSON.parse(raw);
  cart.items = cart.items.filter(i => i.productId !== req.params.productId);
  await client.set(key, JSON.stringify(cart), { EX: CART_TTL_SECONDS });
  res.json(cart);
});

app.delete('/cart/:userId', async (req, res) => {
  await client.del(`cart:${req.params.userId}`);
  res.json({ items: [] });
});

client.connect().then(() => {
  console.log('[cart-service] Redis connected');
  app.listen(PORT, () => console.log(`[cart-service] listening on ${PORT}`));
});
