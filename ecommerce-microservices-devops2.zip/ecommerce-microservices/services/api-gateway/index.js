const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
app.use(cors());
const PORT = process.env.PORT || 4000;

// API Gateway pattern: the browser/mobile app talks to ONE address.
// The gateway hides internal service names/ports and routes each
// path prefix to the right microservice. This is standard in real
// companies (Netflix's Zuul, Kong, AWS API Gateway, etc.) because it
// gives you one place to add auth, rate limiting, logging, and lets
// internal services move/scale without breaking clients.
const routes = [
  { path: '/api/auth', target: process.env.USER_SERVICE_URL || 'http://user-service:4001', rewrite: { '^/api/auth': '' } },
  { path: '/api/users', target: process.env.USER_SERVICE_URL || 'http://user-service:4001', rewrite: { '^/api/users': '/users' } },
  { path: '/api/products', target: process.env.PRODUCT_SERVICE_URL || 'http://product-service:4002', rewrite: { '^/api/products': '/products' } },
  { path: '/api/cart', target: process.env.CART_SERVICE_URL || 'http://cart-service:4003', rewrite: { '^/api/cart': '/cart' } },
  { path: '/api/orders', target: process.env.ORDER_SERVICE_URL || 'http://order-service:4004', rewrite: { '^/api/orders': '/orders' } },
];

routes.forEach(r => {
  app.use(r.path, createProxyMiddleware({ target: r.target, changeOrigin: true, pathRewrite: r.rewrite }));
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'api-gateway' }));

app.listen(PORT, () => console.log(`[api-gateway] listening on ${PORT}`));
