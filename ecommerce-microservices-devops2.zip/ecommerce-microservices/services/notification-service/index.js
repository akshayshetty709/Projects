const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { createClient } = require('redis');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 4005;

// This is the REALTIME piece of the system. The browser opens a
// WebSocket connection here and "joins a room" named after its user
// ID. Meanwhile this service SUBSCRIBES to Redis channel
// 'order_events'. When order-service publishes an event, Redis pushes
// it here instantly, and we forward it down the open WebSocket to the
// exact user it belongs to -- no polling, no refresh needed.
const subscriber = createClient({ url: process.env.REDIS_URL || 'redis://cart-db:6379' });

io.on('connection', (socket) => {
  console.log('[notification-service] client connected', socket.id);

  socket.on('join', (userId) => {
    socket.join(`user:${userId}`);
    console.log(`[notification-service] socket ${socket.id} joined user:${userId}`);
  });

  socket.on('disconnect', () => console.log('[notification-service] client disconnected', socket.id));
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'notification-service' }));

async function start() {
  await subscriber.connect();
  await subscriber.subscribe('order_events', (message) => {
    const event = JSON.parse(message);
    console.log('[notification-service] relaying event ->', event);
    io.to(`user:${event.userId}`).emit('order_update', event);
  });
  server.listen(PORT, () => console.log(`[notification-service] listening on ${PORT}`));
}

start();
