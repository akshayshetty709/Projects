-- Relational schema: users have a fixed structure and relationships
-- (orders, addresses) that benefit from ACID transactions and foreign
-- keys -> this is why User Service uses PostgreSQL.
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
