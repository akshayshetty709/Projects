const { Pool } = require('pg');

// One connection pool shared across requests. Pooling avoids the cost
// of opening a new TCP + auth handshake to Postgres on every request.
const pool = new Pool({
  host: process.env.DB_HOST || 'user-db',
  port: 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'users_db',
});

module.exports = pool;
