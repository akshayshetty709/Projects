const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const pool = require('./db');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 4001;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

async function initDb(retries = 10) {
  const schema = fs.readFileSync(__dirname + '/init.sql', 'utf8');
  while (retries > 0) {
    try {
      await pool.query(schema);
      console.log('[user-service] DB ready');
      return;
    } catch (err) {
      console.log('[user-service] DB not ready, retrying...', err.message);
      retries--;
      await new Promise(r => setTimeout(r, 3000));
    }
  }
  throw new Error('Could not connect to DB');
}

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'user-service' }));

app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (name, email, password_hash) VALUES ($1,$2,$3) RETURNING id, name, email',
      [name, email, hash]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'email already registered' });
    console.error(err);
    res.status(500).json({ error: 'internal error' });
  }
});

app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'invalid credentials' });
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '2h' });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal error' });
  }
});

app.get('/users/:id', async (req, res) => {
  const result = await pool.query('SELECT id, name, email FROM users WHERE id=$1', [req.params.id]);
  if (!result.rows[0]) return res.status(404).json({ error: 'not found' });
  res.json(result.rows[0]);
});

initDb().then(() => {
  app.listen(PORT, () => console.log(`[user-service] listening on ${PORT}`));
});
