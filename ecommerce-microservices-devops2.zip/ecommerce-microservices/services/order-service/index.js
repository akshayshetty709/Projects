const express = require('express');
const fs = require('fs');
const axios = require('axios');
const { createClient } = require('redis');
const pool = require('./db');

const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4004;
const PRODUCT_SERVICE_URL = process.env.PRODUCT_SERVICE_URL || 'http://product-service:4002';

// Redis doubles here as a lightweight PUBLISH/SUBSCRIBE message bus.
// Order-service PUBLISHES "order status changed" events; notification
// -service SUBSCRIBES and pushes them to the browser over a WebSocket
// in real time. This decouples the two services: order-service doesn't
// need to know who's listening, or even that anyone is.
const publisher = createClient({ url: process.env.REDIS_URL || 'redis://cart-db:6379' });

async function initDb(retries = 10) {
  const schema = fs.readFileSync(__dirname + '/init.sql', 'utf8');
  while (retries > 0) {
    try {
      await pool.query(schema);
      console.log('[order-service] DB ready');
      return;
    } catch (err) {
      console.log('[order-service] DB not ready, retrying...', err.message);
      retries--;
      await new Promise(r => setTimeout(r, 3000));
    }
  }
  throw new Error('Could not connect to DB');
}

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'order-service' }));

// Create an order: reserve stock in product-service, then write the
// order + items as ONE atomic DB transaction.
app.post('/orders', async (req, res) => {
  const { userId, items } = req.body; // items: [{productId, name, price, quantity}]
  if (!userId || !items || !items.length) return res.status(400).json({ error: 'userId and items required' });

  const client = await pool.connect();
  try {
    // Reserve stock for each item first (fail fast before touching DB)
    for (const item of items) {
      await axios.post(`${PRODUCT_SERVICE_URL}/products/${item.productId}/reserve`, { quantity: item.quantity });
    }

    const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

    await client.query('BEGIN');
    const orderResult = await client.query(
      'INSERT INTO orders (user_id, status, total) VALUES ($1,$2,$3) RETURNING *',
      [userId, 'CONFIRMED', total]
    );
    const order = orderResult.rows[0];

    for (const item of items) {
      await client.query(
        'INSERT INTO order_items (order_id, product_id, name, price, quantity) VALUES ($1,$2,$3,$4,$5)',
        [order.id, item.productId, item.name, item.price, item.quantity]
      );
    }
    await client.query('COMMIT');

    // Fire a realtime event -- this is what the browser sees instantly
    await publisher.publish('order_events', JSON.stringify({
      type: 'ORDER_CREATED', userId, orderId: order.id, status: order.status, total
    }));

    res.status(201).json({ ...order, items });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err.message);
    res.status(500).json({ error: 'order failed', detail: err.message });
  } finally {
    client.release();
  }
});

app.get('/orders/:id', async (req, res) => {
  const order = await pool.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
  if (!order.rows[0]) return res.status(404).json({ error: 'not found' });
  const items = await pool.query('SELECT * FROM order_items WHERE order_id=$1', [req.params.id]);
  res.json({ ...order.rows[0], items: items.rows });
});

app.get('/users/:userId/orders', async (req, res) => {
  const orders = await pool.query('SELECT * FROM orders WHERE user_id=$1 ORDER BY created_at DESC', [req.params.userId]);
  res.json(orders.rows);
});

// Simulate order progressing through fulfillment (packed -> shipped ->
// delivered), publishing a realtime event at every step.
app.patch('/orders/:id/status', async (req, res) => {
  const { status } = req.body;
  const result = await pool.query(
    'UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
    [status, req.params.id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'not found' });
  const order = result.rows[0];
  await publisher.publish('order_events', JSON.stringify({
    type: 'ORDER_STATUS_CHANGED', userId: order.user_id, orderId: order.id, status
  }));
  res.json(order);
});

Promise.all([initDb(), publisher.connect()]).then(() => {
  app.listen(PORT, () => console.log(`[order-service] listening on ${PORT}`));
});
