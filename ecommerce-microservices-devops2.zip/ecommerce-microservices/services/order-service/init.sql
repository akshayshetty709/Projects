-- Orders involve MONEY and inventory changes: they need ACID
-- transactions (an order + its line items must be created together,
-- or not at all) and relational integrity -> this is why Order
-- Service uses PostgreSQL, same reasoning as User Service.
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    total NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
    product_id VARCHAR(50) NOT NULL,
    name VARCHAR(200),
    price NUMERIC(10,2) NOT NULL,
    quantity INTEGER NOT NULL
);
