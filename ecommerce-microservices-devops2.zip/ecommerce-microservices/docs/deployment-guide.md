# Deployment Guide — Deep Dive

## Local: Docker Compose
`docker-compose.yml` is the "everything on one machine" version. Each
service and database is a container; Docker's internal DNS lets containers
find each other by service name (e.g. `user-service` connects to `user-db`
just by hostname — no IP management needed).

Key details:
- `depends_on: { condition: service_healthy }` makes app services wait
  for their database's healthcheck to pass before starting — but every
  service ALSO has its own retry loop in code (`initDb()` /
  `connectWithRetry()`), because "depends_on" only checks the container
  started, not that the app inside is fully ready. Belt and suspenders —
  this is how real teams avoid flaky container startup races.

## Production-style: Kubernetes
Kubernetes manifests are applied in this order because later resources
depend on earlier ones existing:
1. `namespace.yaml` — isolates all these resources under `ecommerce`.
2. `configmap.yaml` / `secrets.yaml` — non-secret and secret configuration,
   referenced by every deployment via `envFrom`/`secretKeyRef`.
3. `databases.yaml` — stateful deployments with PersistentVolumeClaims so
   data survives pod restarts.
4. Each service's own file — stateless deployments (2 replicas each) with
   **readiness/liveness probes** hitting `/health`. Kubernetes uses these
   to know when a pod can receive traffic and when to restart a stuck one.
5. `ingress.yaml` — single external entry point, mirroring the API Gateway
   pattern but at the cluster's edge.

## Secrets — an important real-world caveat
`k8s/secrets.yaml` in this repo has plaintext placeholder values so it's
easy to practice with. **Never commit real secrets like this.** In actual
companies:
- Secrets live in a vault (AWS Secrets Manager, GCP Secret Manager,
  HashiCorp Vault) and are injected at deploy time, OR
- Repos use "sealed secrets" / SOPS-encrypted files that are safe to commit
  because they're encrypted and only your cluster can decrypt them.

## CI/CD flow
See `.github/workflows/ci-cd.yaml`. The three jobs (`test` →
`build-and-push` → `deploy`) run in sequence via `needs:`, and
`build-and-push`/`deploy` are gated to only run on `main`
(`if: github.ref == 'refs/heads/main'`) so pull requests only run tests,
never push images or touch the live cluster. Images are tagged with the
git commit SHA so you can always trace a running pod back to exact source
code — critical for debugging production incidents and for rollbacks
(`kubectl rollout undo`).

## Scaling exercise
```bash
kubectl -n ecommerce scale deployment/product-service --replicas=5
kubectl -n ecommerce get pods -w
```
Notice `user-service`/`order-service` (stateful-adjacent, tied to Postgres
connection limits) usually scale more conservatively than stateless
read-heavy services like `product-service`.
