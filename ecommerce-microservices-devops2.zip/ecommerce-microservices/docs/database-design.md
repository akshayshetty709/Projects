# Database Design — Deep Dive

## Polyglot persistence
This project uses **4 different databases for 4 different jobs** instead
of forcing everything into one. This is called "polyglot persistence" and
is standard at companies operating at scale (Netflix, Uber, Amazon all mix
Postgres/MySQL, DynamoDB/Mongo, and Redis across their systems).

## PostgreSQL (user-service, order-service)
- **Data shape:** rows with fixed columns, strong relationships (an order
  belongs to a user; order_items belong to an order via foreign key).
- **Guarantee needed:** ACID transactions. Look at `order-service/index.js`:
  creating an order runs `BEGIN` → insert order → insert order_items →
  `COMMIT`. If anything fails partway, `ROLLBACK` undoes everything, so you
  never get billed for an order that was never actually recorded.
- **Trade-off:** schema changes need migrations; scaling writes horizontally
  is harder than with NoSQL. Acceptable here because orders/users aren't
  the highest-volume writes in a typical shop, and correctness matters more
  than raw throughput for money-related data.

## MongoDB (product-service)
- **Data shape:** documents with attributes that vary by category. This
  project stores category-specific fields inside a flexible `attributes`
  object rather than fixed columns.
- **Guarantee needed:** flexibility and read speed (product pages are read
  far more than they're written), not multi-document transactions.
- **Trade-off:** no cross-document ACID transactions (in this project we
  don't need any — each product update is self-contained), less strict
  schema (which is a feature here, not a bug).

## Redis (cart-service, and pub/sub for order-service/notification-service)
- **Data shape (cart):** a simple JSON blob per user, keyed by `cart:<userId>`.
- **Guarantee needed:** speed (in-memory) and automatic expiry (`EX` TTL) —
  we don't want abandoned carts sitting forever, and we don't want a cron
  job to clean them up either.
- **Second job — pub/sub:** Redis also acts as a lightweight message bus
  between order-service (publisher) and notification-service (subscriber).
  This is NOT persistent storage — if no one is subscribed when a message
  publishes, it's lost. That's fine for "push a live UI update"; it would
  NOT be fine for "the order must eventually be processed" (for that,
  real systems use Kafka, RabbitMQ, or AWS SQS, which persist messages
  until they're consumed).

## What would change at real scale
- Product read replicas / a search engine (Elasticsearch) in front of Mongo
  for full-text search.
- Postgres read replicas for order history queries.
- Replace Redis pub/sub with Kafka/RabbitMQ once you need guaranteed
  delivery (e.g. "send a confirmation email" must never be silently lost).
- Add a caching layer (Redis again, different keys) in front of
  product-service for hot product pages.
