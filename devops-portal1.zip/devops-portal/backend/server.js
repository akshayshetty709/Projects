const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const client = require('prom-client');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

// ---- Prometheus metrics ----
const register = new client.Registry();
client.collectDefaultMetrics({ register, prefix: 'devops_portal_' });

const httpRequestDuration = new client.Histogram({
  name: 'devops_portal_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5],
  registers: [register],
});

const httpRequestsTotal = new client.Counter({
  name: 'devops_portal_http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code'],
  registers: [register],
});

const activeConnectionsGauge = new client.Gauge({
  name: 'devops_portal_active_socket_connections',
  help: 'Number of currently connected WebSocket clients',
  registers: [register],
});

const simulatedServiceLatency = new client.Gauge({
  name: 'devops_portal_simulated_service_latency_ms',
  help: 'Simulated latency per downstream service shown on the dashboard',
  labelNames: ['service'],
  registers: [register],
});

app.use((req, res, next) => {
  const endTimer = httpRequestDuration.startTimer();
  res.on('finish', () => {
    // Use req.route when available to avoid a high-cardinality label from raw paths
    const route = req.route ? req.baseUrl + req.route.path : req.path;
    const labels = { method: req.method, route, status_code: res.statusCode };
    endTimer(labels);
    httpRequestsTotal.inc(labels);
  });
  next();
});

// ---- In-memory "state of the world" for the demo ----
const services = [
  { id: 'checkout-api', label: 'checkout-api', status: 'healthy', replicas: 3, latencyMs: 42 },
  { id: 'payments-api', label: 'payments-api', status: 'healthy', replicas: 3, latencyMs: 58 },
  { id: 'catalog-api', label: 'catalog-api', status: 'warn', replicas: 2, latencyMs: 145 },
  { id: 'auth-service', label: 'auth-service', status: 'healthy', replicas: 4, latencyMs: 31 },
  { id: 'notification-worker', label: 'notification-worker', status: 'healthy', replicas: 2, latencyMs: 20 },
  { id: 'search-index', label: 'search-index', status: 'healthy', replicas: 3, latencyMs: 77 },
];

const eventTemplates = [
  (s) => `Build #${100 + Math.floor(Math.random() * 900)} passed for ${s}`,
  (s) => `Rolling update started for ${s}`,
  (s) => `Pod restarted: ${s}-${Math.floor(Math.random() * 9000)}`,
  (s) => `Deployed ${s} to production`,
  (s) => `Health check recovered for ${s}`,
  (s) => `Autoscaler added a replica to ${s}`,
];

let events = [];

function randomStatus(current) {
  const roll = Math.random();
  if (roll < 0.85) return current;
  const options = ['healthy', 'warn', 'critical'];
  return options[Math.floor(Math.random() * options.length)];
}

function tick() {
  services.forEach((svc) => {
    svc.status = randomStatus(svc.status);
    svc.latencyMs = Math.max(8, Math.round(svc.latencyMs + (Math.random() - 0.5) * 30));
    simulatedServiceLatency.set({ service: svc.id }, svc.latencyMs);
  });

  if (Math.random() < 0.6) {
    const svc = services[Math.floor(Math.random() * services.length)];
    const template = eventTemplates[Math.floor(Math.random() * eventTemplates.length)];
    const event = {
      id: Date.now(),
      time: new Date().toISOString(),
      message: template(svc.label),
    };
    events.unshift(event);
    events = events.slice(0, 30);
    io.emit('event', event);
  }

  io.emit('services', services);
}

setInterval(tick, 2500);

// ---- REST API (also usable without the socket) ----
app.get('/api/services', (req, res) => res.json(services));
app.get('/api/events', (req, res) => res.json(events));
app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }));

io.on('connection', (socket) => {
  activeConnectionsGauge.inc();
  socket.emit('services', services);
  socket.emit('events-init', events);
  socket.on('disconnect', () => activeConnectionsGauge.dec());
});

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// ---- Serve the built React app ----
const staticDir = path.join(__dirname, 'public');
app.use(express.static(staticDir));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path === '/health' || req.path === '/metrics') return next();
  res.sendFile(path.join(staticDir, 'index.html'));
});

if (require.main === module) {
  server.listen(PORT, () => console.log(`devops-portal listening on ${PORT}`));
}

module.exports = { app, server };
