# Signal — Real-Time DevOps Portal

A live-updating DevOps dashboard: service health, latency sparklines, and a
streaming event log, pushed to the browser over WebSockets (Socket.io). Same
Jenkins → Docker Hub → EKS flow as the earlier demo.

> The metrics/events are simulated in `backend/server.js` (`tick()`,
> every 2.5s) so the portal is live and demo-able with no other infra wired
> up. Swap that function for real calls to the Kubernetes API, Prometheus,
> or the Jenkins API to make it show your actual environment.

## Project layout

```
.
├── backend/
│   ├── server.js         # Express API + Socket.io + serves the built frontend
│   ├── server.test.js
│   └── package.json
├── frontend/               # React (Vite)
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   └── components/
│   │       ├── ServiceCard.jsx
│   │       ├── Pulse.jsx    # live canvas sparkline per service
│   │       └── EventLog.jsx # terminal-style live event tail
│   └── package.json
├── Dockerfile               # builds frontend, bundles into the backend image
├── Jenkinsfile
└── k8s/
    ├── namespace.yaml
    ├── deployment.yaml
    └── service.yaml         # ClientIP session affinity for sticky websockets
```

## One-time setup on your Jenkins server

Same as the API demo:

1. Plugins: `Pipeline`, `Docker Pipeline`, `Credentials Binding`,
   `Amazon Web Services SDK :: All` (or `pipeline-aws`).
2. Agent needs `docker`, `node`/`npm`, `kubectl`, `aws` CLI on `PATH`.
3. Credentials in Jenkins:
   - `dockerhub-creds` — Docker Hub username + access token.
   - `aws-eks-creds` — AWS credentials for a principal that can
     `eks:DescribeCluster` and deploy into the `devops-portal` namespace.
4. Edit the `TODO`s in `Jenkinsfile`: `DOCKERHUB_USER`, `EKS_CLUSTER_NAME`,
   `AWS_REGION`.
5. Point a Jenkins Pipeline job at this repo.

## What the pipeline does

1. Checkout.
2. **Backend**: `npm ci` + `npm test` (Jest/Supertest against the Express
   API).
3. **Frontend**: `npm install` + `npm run build` (Vite build — this isn't
   strictly required before the Docker stage since the Dockerfile rebuilds
   it too, but it fails the pipeline fast if the frontend doesn't compile).
4. **Docker Build** — a 3-stage build: compile the frontend, install backend
   deps, then a slim runtime image that serves both the static frontend and
   the API/WebSocket from one Express process on port 3000.
5. **Docker Push** to Docker Hub (`<user>/devops-portal:<build-number>` and
   `:latest`).
6. **Configure kubectl** via `aws eks update-kubeconfig`.
7. **Deploy to EKS** — applies the namespace/service, templates the new
   image tag into `deployment.yaml`, applies it, and waits on
   `kubectl rollout status`.

## Running locally

```bash
# terminal 1 — backend
cd backend
npm install
npm start            # http://localhost:3000 (API + socket)

# terminal 2 — frontend dev server (proxies /api and /socket.io to :3000)
cd frontend
npm install
npm run dev           # http://localhost:5173
```

Or build the single production image:

```bash
docker build -t devops-portal:local .
docker run -p 3000:3000 devops-portal:local
# open http://localhost:3000
```

## Verifying the deployment

```bash
kubectl get pods -n devops-portal
kubectl get svc devops-portal -n devops-portal   # EXTERNAL-IP is the ELB hostname
curl http://<EXTERNAL-IP>/health
```
Open `http://<EXTERNAL-IP>` in a browser — the service cards and event log
should update every couple of seconds.

## Monitoring (Prometheus + Grafana)

This adds real, cluster-wide monitoring via the `kube-prometheus-stack` Helm
chart (Prometheus + Grafana + Alertmanager + node-exporter + kube-state-metrics),
plus real application metrics from the portal itself.

```
k8s/monitoring/
├── prometheus-values.yaml            # Helm values for kube-prometheus-stack
├── servicemonitor.yaml               # tells Prometheus to scrape the portal's /metrics
└── grafana-dashboard-devops-portal.json  # importable Grafana dashboard
```

**What's actually real here:** the backend now uses `prom-client` to expose
genuine process/runtime metrics (event loop lag, memory, GC) and app metrics
(HTTP request rate/latency by route, active WebSocket connections) at
`GET /metrics`. This is separate from — and more trustworthy than — the
simulated service cards on the dashboard itself, which are still fake data
for demo purposes (see the note near the top of this file).

### 1. Install the stack (one-time, cluster-wide)

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring --create-namespace \
  -f k8s/monitoring/prometheus-values.yaml
```

This installs the Prometheus Operator and its CRDs (including
`ServiceMonitor`), which is why `servicemonitor.yaml` must be applied
*after* this step — the Jenkinsfile's deploy stage already does this
best-effort (it won't fail the build if the CRDs aren't installed yet).

### 2. Point Prometheus at the portal

Already wired up:
- `backend/server.js` exposes `/metrics` in Prometheus text format.
- `k8s/service.yaml` names the port `http` so...
- `k8s/monitoring/servicemonitor.yaml` can select it and tell Prometheus to
  scrape `/metrics` every 15s.

Apply it manually if you're not going through Jenkins yet:

```bash
kubectl apply -f k8s/monitoring/servicemonitor.yaml
```

### 3. View it

```bash
# Grafana (default admin password is set in prometheus-values.yaml — change it)
kubectl port-forward -n monitoring svc/prometheus-grafana 3001:80
# open http://localhost:3001  (user: admin)

# Prometheus UI, to sanity-check the scrape target directly
kubectl port-forward -n monitoring svc/prometheus-kube-prometheus-prometheus 9090:9090
# open http://localhost:9090/targets and look for devops-portal/devops-portal
```

In Grafana: **Dashboards → New → Import**, upload
`k8s/monitoring/grafana-dashboard-devops-portal.json`. It has panels for
request rate, p95 latency, active WebSocket connections, simulated service
latency, memory, and event loop lag — all backed by real scraped metrics.

The chart's built-in dashboards (from kube-state-metrics/node-exporter) also
give you cluster-wide CPU/memory/pod status out of the box, with no extra
config.

## Notes for a real deployment

- **Scaling past 2 replicas**: Socket.io needs either sticky sessions (the
  Service already sets `sessionAffinity: ClientIP`) or a shared adapter
  (e.g. `@socket.io/redis-adapter`) if you want broadcasts to reach clients
  connected to *other* pods. For a dashboard where each pod independently
  simulates/fetches the same state, sticky sessions alone are enough.
- Replace the simulated `tick()` with real data sources: the Kubernetes API
  (via `@kubernetes/client-node`) for pod/deployment status, and the Jenkins
  REST API for build results.
- As before: prefer IRSA/OIDC over static AWS keys, consider an ALB Ingress
  with TLS instead of a bare LoadBalancer Service, and pin image digests for
  production.
