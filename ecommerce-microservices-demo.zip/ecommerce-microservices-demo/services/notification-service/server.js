// notification-service
// This is the "realtime" half of the system. It keeps a WebSocket
// (Socket.IO) connection open with every browser that's tracking an
// order, and subscribes to the "order-status" Redis channel that
// order-service publishes to. The moment a status change is published,
// it's pushed straight to the browser — no polling, no delay.
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { createClient } = require('redis');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  path: '/socket.io',
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 4004;
const REDIS_URL = process.env.REDIS_URL || 'redis://redis:6379';

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'notification-service' }));

io.on('connection', (socket) => {
  // A client tells us which order it cares about; we put it in a room
  // named after that order so broadcasts only reach interested clients.
  socket.on('subscribe-order', (orderId) => {
    socket.join(`order-${orderId}`);
  });
});

async function start() {
  const subscriber = createClient({ url: REDIS_URL });
  subscriber.on('error', (err) => console.error('Redis subscriber error:', err.message));

  await subscriber.connect();
  await subscriber.subscribe('order-status', (message) => {
    let payload;
    try {
      payload = JSON.parse(message);
    } catch (err) {
      console.error('Bad order-status payload:', err.message);
      return;
    }
    io.to(`order-${payload.orderId}`).emit('order-update', payload);
  });
  console.log('notification-service subscribed to Redis channel "order-status"');

  server.listen(PORT, () => console.log(`notification-service listening on ${PORT}`));
}

start().catch((err) => {
  console.error('notification-service failed to start:', err.message);
  process.exit(1);
});
