// catalog-service
// Owns restaurant + menu data. This is the ONLY service allowed to know
// menu prices — cart-service calls it to get authoritative prices instead
// of trusting whatever price the browser sends.
const express = require('express');
const app = express();
const PORT = process.env.PORT || 4001;

const restaurants = [
  { id: 1, name: "Sangeetha Veg Restaurant", cuisine: "South Indian", rating: 4.3 },
  { id: 2, name: "Anjappar Chettinad", cuisine: "Chettinad", rating: 4.5 },
  { id: 3, name: "Domino's Pizza", cuisine: "Fast Food", rating: 4.1 }
];

const menus = {
  1: [{ item: "Masala Dosa", price: 90 }, { item: "Idli Sambar", price: 60 }],
  2: [{ item: "Chicken Chettinad", price: 320 }, { item: "Mutton Biryani", price: 280 }],
  3: [{ item: "Margherita Pizza", price: 249 }, { item: "Farmhouse Pizza", price: 399 }]
};

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'catalog-service' }));
app.get('/restaurants', (req, res) => res.json(restaurants));

app.get('/restaurants/:id', (req, res) => {
  const r = restaurants.find(x => x.id === Number(req.params.id));
  if (!r) return res.status(404).json({ error: 'Restaurant not found' });
  res.json(r);
});

app.get('/restaurants/:id/menu', (req, res) => {
  const menu = menus[req.params.id];
  if (!menu) return res.status(404).json({ error: 'Restaurant not found' });
  res.json(menu);
});

app.listen(PORT, () => console.log(`catalog-service listening on ${PORT}`));
