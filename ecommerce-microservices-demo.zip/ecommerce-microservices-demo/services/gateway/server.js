// gateway
// A pure API gateway now — it does NOT serve any HTML. The frontend is
// its own separate microservice (services/frontend, nginx), which is what
// the browser actually loads. The frontend's nginx proxies /api and
// /socket.io traffic to this gateway, which then routes it on to:
//   /api/restaurants*  -> catalog-service
//   /api/orders*       -> order-service   (cart pricing happens inside order-service, which itself calls cart-service)
//   /socket.io*        -> notification-service (WebSocket, upgraded)
const express = require('express');
const http = require('http');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 4000;

const CATALOG_URL = process.env.CATALOG_URL || 'http://catalog-service:4001';
const ORDER_URL = process.env.ORDER_URL || 'http://order-service:4003';
const NOTIFICATION_URL = process.env.NOTIFICATION_URL || 'http://notification-service:4004';

app.use('/api/restaurants', createProxyMiddleware({
  target: CATALOG_URL,
  changeOrigin: true,
  pathRewrite: { '^/api': '' }
}));

app.use('/api/orders', createProxyMiddleware({
  target: ORDER_URL,
  changeOrigin: true,
  pathRewrite: { '^/api': '' }
}));

const socketProxy = createProxyMiddleware({
  target: NOTIFICATION_URL,
  changeOrigin: true,
  ws: true
});
app.use('/socket.io', socketProxy);
// WebSocket upgrades happen at the raw HTTP server level, not through
// normal Express routing, so the proxy needs to be attached here too.
server.on('upgrade', socketProxy.upgrade);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'gateway' }));

server.listen(PORT, () => console.log(`gateway listening on ${PORT}`));
