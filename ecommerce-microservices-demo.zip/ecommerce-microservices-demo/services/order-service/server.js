// order-service
// Creates orders (after getting an authoritative price quote from
// cart-service), stores them in memory, and runs a simulated delivery
// lifecycle. Every status change is PUBLISHED to Redis on the
// "order-status" channel — order-service does not know or care who is
// listening. notification-service is the one that turns that into a
// live push to the browser. This decoupling (publish now, someone reacts
// later) is the core idea behind "realtime" in an event-driven system.
const express = require('express');
const { createClient } = require('redis');

const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4003;
const CART_URL = process.env.CART_URL || 'http://cart-service:4002';
const REDIS_URL = process.env.REDIS_URL || 'redis://redis:6379';

const PAYMENT_METHODS = ['cod', 'upi', 'card'];
const STATUS_FLOW = ['placed', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'];
const STAGE_DELAY_MS = 6000;

let orders = [];
let orderIdCounter = 1;

const publisher = createClient({ url: REDIS_URL });
publisher.on('error', (err) => console.error('Redis publisher error:', err.message));

async function publishStatus(order) {
  try {
    await publisher.publish('order-status', JSON.stringify({
      orderId: order.id,
      status: order.status,
      statusHistory: order.statusHistory,
      at: order.statusHistory[order.statusHistory.length - 1].at
    }));
  } catch (err) {
    console.error('Failed to publish order status:', err.message);
  }
}

function advanceOrder(order) {
  const currentIndex = STATUS_FLOW.indexOf(order.status);
  if (currentIndex === -1 || currentIndex === STATUS_FLOW.length - 1) return;
  order.status = STATUS_FLOW[currentIndex + 1];
  order.statusHistory.push({ status: order.status, at: new Date().toISOString() });
  publishStatus(order);
  if (order.status !== 'delivered') {
    setTimeout(() => advanceOrder(order), STAGE_DELAY_MS);
  }
}

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'order-service' }));

app.post('/orders', async (req, res) => {
  const { restaurantId, items, deliveryAddress, phone, paymentMethod } = req.body || {};

  if (!deliveryAddress || !String(deliveryAddress).trim()) {
    return res.status(400).json({ error: 'deliveryAddress is required' });
  }
  if (!phone || !/^[0-9]{10}$/.test(String(phone).trim())) {
    return res.status(400).json({ error: 'phone must be a 10-digit number' });
  }
  if (!PAYMENT_METHODS.includes(paymentMethod)) {
    return res.status(400).json({ error: `paymentMethod must be one of ${PAYMENT_METHODS.join(', ')}` });
  }

  // Ask cart-service for the authoritative price — never trust client-sent prices.
  let quote;
  try {
    const quoteRes = await fetch(`${CART_URL}/cart/quote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ restaurantId, items })
    });
    quote = await quoteRes.json();
    if (!quoteRes.ok) return res.status(400).json({ error: quote.error || 'Could not price this cart' });
  } catch (err) {
    console.error('cart-service unreachable:', err.message);
    return res.status(502).json({ error: 'cart-service unavailable' });
  }

  let restaurantName = `Restaurant #${quote.restaurantId}`;
  try {
    const catalogUrl = process.env.CATALOG_URL || 'http://catalog-service:4001';
    const rRes = await fetch(`${catalogUrl}/restaurants/${quote.restaurantId}`);
    if (rRes.ok) restaurantName = (await rRes.json()).name;
  } catch (err) {
    console.error('Could not fetch restaurant name:', err.message);
  }

  const now = new Date().toISOString();
  const order = {
    id: orderIdCounter++,
    restaurantId: quote.restaurantId,
    restaurantName,
    items: quote.items,
    subtotal: quote.subtotal,
    deliveryFee: quote.deliveryFee,
    total: quote.total,
    deliveryAddress: String(deliveryAddress).trim(),
    phone: String(phone).trim(),
    paymentMethod,
    status: 'placed',
    statusHistory: [{ status: 'placed', at: now }],
    estimatedDeliveryMinutes: 25 + Math.floor(Math.random() * 16),
    createdAt: now
  };

  orders.push(order);
  publishStatus(order);
  setTimeout(() => advanceOrder(order), STAGE_DELAY_MS);

  res.status(201).json(order);
});

app.get('/orders/:id', (req, res) => {
  const order = orders.find(o => o.id === Number(req.params.id));
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

async function start() {
  try {
    await publisher.connect();
    console.log('order-service connected to Redis');
  } catch (err) {
    console.error('Could not connect to Redis at startup, will retry on first publish:', err.message);
  }
  app.listen(PORT, () => console.log(`order-service listening on ${PORT}`));
}

start();
