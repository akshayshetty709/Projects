// cart-service
// Takes a proposed cart (restaurantId + items with quantities) and prices
// it authoritatively by calling catalog-service — the browser is never
// trusted to say what something costs. This is the "service-to-service
// call" piece of the architecture.
const express = require('express');
const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4002;
const CATALOG_URL = process.env.CATALOG_URL || 'http://catalog-service:4001';
const DELIVERY_FEE = 25;

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'cart-service' }));

app.post('/cart/quote', async (req, res) => {
  const { restaurantId, items } = req.body || {};

  if (!restaurantId) return res.status(400).json({ error: 'restaurantId is required' });
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'items must be a non-empty array of { item, qty }' });
  }

  let menu;
  try {
    const menuRes = await fetch(`${CATALOG_URL}/restaurants/${restaurantId}/menu`);
    if (!menuRes.ok) return res.status(400).json({ error: 'Unknown restaurantId' });
    menu = await menuRes.json();
  } catch (err) {
    console.error('catalog-service unreachable:', err.message);
    return res.status(502).json({ error: 'catalog-service unavailable' });
  }

  const pricedItems = [];
  for (const requested of items) {
    const menuItem = menu.find(m => m.item === requested.item);
    if (!menuItem) {
      return res.status(400).json({ error: `"${requested.item}" is not on this restaurant's menu` });
    }
    const qty = Number(requested.qty);
    if (!Number.isFinite(qty) || qty < 1) {
      return res.status(400).json({ error: `invalid quantity for "${requested.item}"` });
    }
    pricedItems.push({ item: menuItem.item, price: menuItem.price, qty });
  }

  const subtotal = pricedItems.reduce((sum, i) => sum + i.price * i.qty, 0);
  const total = subtotal + DELIVERY_FEE;

  res.json({
    restaurantId: Number(restaurantId),
    items: pricedItems,
    subtotal,
    deliveryFee: DELIVERY_FEE,
    total
  });
});

app.listen(PORT, () => console.log(`cart-service listening on ${PORT}`));
