# Ruchi — E-Commerce Microservices Demo (with realtime order tracking)

This is your Zomato-style food ordering app, rebuilt as **5 independent
microservices** instead of one app, with **live WebSocket order tracking**
instead of polling. Same DevOps pipeline pattern you already have working
(Jenkins → Docker Hub → EKS) — just applied to 5 images instead of 1.

Read this top to bottom once before you deploy anything. It explains *why*
each piece exists, not just what to type.

---

## 1. Why microservices at all?

Your original project was one app doing everything: restaurants, menus,
orders, all in one `server.js`. That's fine for a demo, but it doesn't teach
or demonstrate the thing real companies use microservices for: **each part
can be built, deployed, scaled, and fixed independently.**

If `order-service` crashes, `catalog-service` keeps serving menus. If Diwali
traffic hits and everyone's browsing restaurants but not ordering, you scale
`catalog-service` to 5 replicas and leave the others at 1. You cannot do
that with one monolithic app.

## 2. The five services

```
                         ┌─────────────┐
   Browser  ───────────▶ │   gateway   │  (the only thing the browser talks to)
   (Ruchi UI)             └──────┬──────┘
                    ┌────────────┼─────────────┬───────────────┐
                    │            │              │               │
                    ▼            ▼              ▼               ▼
           /api/restaurants  /api/orders   /socket.io      (static files:
                    │            │              │           the UI itself)
                    ▼            ▼              ▼
           ┌────────────┐ ┌─────────────┐ ┌──────────────────┐
           │  catalog-  │ │   order-    │ │  notification-   │
           │  service   │ │   service   │ │  service          │
           └────────────┘ └──────┬──────┘ └─────────┬─────────┘
                 ▲                │  calls also        │
                 │                ▼                    │
                 │         ┌─────────────┐             │
                 └─────────┤ cart-service │             │
                           └─────────────┘             │
                                  │  publishes           │  subscribes
                                  ▼                      ▼
                              ┌────────────────────────────┐
                              │            Redis            │
                              │     (pub/sub message bus)   │
                              └────────────────────────────┘
```

| Service | Job | Talks to |
|---|---|---|
| **gateway** | The only public entry point. Serves the frontend, routes `/api/*` calls, proxies the WebSocket. | catalog, order, notification |
| **catalog-service** | Owns restaurant + menu data. The only service that knows prices. | — |
| **cart-service** | Prices a cart. Looks up real prices from catalog-service instead of trusting the browser. | catalog-service |
| **order-service** | Creates orders, runs the delivery status lifecycle (placed → confirmed → preparing → out for delivery → delivered), publishes every status change to Redis. | cart-service, catalog-service, Redis |
| **notification-service** | Holds a live WebSocket connection with every browser tracking an order. Listens to Redis and pushes updates instantly. | Redis |
| **Redis** | The message bus. Not a database here — just the pipe that carries "order 7 just changed to preparing" from order-service to notification-service. | — |

## 3. How "realtime" actually works here

This is the part worth understanding, not just copying.

Your old version used **polling**: the browser asked `GET /orders/:id` every
3 seconds, "any update? any update? any update?" — wasteful, and delayed by
up to 3 seconds.

The new version uses **push**:

1. Browser places an order, then opens a WebSocket to `notification-service`
   (through the gateway) and says "tell me about order #7."
2. `order-service`'s internal timer moves the order from `placed` to
   `confirmed`. The instant that happens, it publishes a message to Redis
   on the channel `order-status`.
3. `notification-service` is subscribed to that channel. The message
   arrives instantly and it forwards it to whichever browser sockets asked
   about order #7.
4. The browser's UI updates the same millisecond — no delay, no wasted
   requests.

This publish/subscribe pattern (Redis pub/sub) is a small version of what
companies do with Kafka or RabbitMQ at scale. Same idea, much simpler
plumbing — perfect for learning it.

## 4. Test it locally first (do this before touching Jenkins)

You need Docker + Docker Compose installed. From the project root:

```bash
docker compose up --build
```

Wait for all 6 containers to report healthy, then open **http://localhost:4000**
in a browser. Browse restaurants, add items to cart, checkout, and watch the
order tracker move through stages live — this is the exact same code that
will run on EKS, just without Kubernetes in the way. If something's broken,
it's much faster to find out here than in a Jenkins log.

Stop it with `docker compose down` when you're done.

## 5. Deploying to EKS via Jenkins

You already have the Jenkins → Docker Hub → EKS pipeline working from the
previous project, so the credentials are already set up:

- `dockerhub-creds` (username/password) — reused as-is
- `kubeconfig-creds` (secret file) — reused as-is, must point at your
  current EKS cluster (the one you already fixed earlier)
- The IAM identity behind your kubeconfig must already have access to the
  cluster (you set this up with `create-access-entry` earlier)

**Steps:**

1. Push this whole folder to a new GitHub repo (or a new branch of your
   existing one).
2. In Jenkins, create a new Pipeline job pointing at it, same as before.
3. Run it. The `Jenkinsfile` does, in order:
   - Builds all 5 Docker images
   - Pushes all 5 to Docker Hub under `<your-dockerhub-username>/ecommerce-<service>`
   - Replaces the `YOUR_DOCKERHUB_USERNAME` placeholder in the k8s manifests
     with your real Docker Hub username (using `sed`, automatically —
     you don't need to edit the YAML files by hand)
   - Applies the namespace, Redis, and all 5 service manifests to your
     cluster
   - Forces every deployment to pull the freshly-pushed `:latest` image
     (`kubectl rollout restart`) — this matters because Kubernetes doesn't
     automatically notice that `:latest` now points at something new

4. Once it finishes:
   ```bash
   kubectl -n ecommerce get pods
   kubectl -n ecommerce get svc gateway
   ```
   The `gateway` service is `type: LoadBalancer`, so AWS will give it a
   public ELB address — same as your original `/restaurants` endpoint.
   Open that address in a browser.

## 6. Verifying it's actually working end to end

```bash
kubectl -n ecommerce get pods
```
All pods should be `Running` with `READY 1/1`. If `order-service` or
`notification-service` are crash-looping, it's almost always because they
can't reach Redis — check:
```bash
kubectl -n ecommerce logs deployment/order-service
kubectl -n ecommerce get svc redis
```

Then in the browser: place an order and watch it move through
"Order placed → Confirmed → Preparing → Out for delivery → Delivered"
on its own, roughly every 6 seconds, without refreshing the page. That's
the realtime pipeline working.

## 7. Honest limitations (worth knowing, not hiding)

- **Payment is simulated.** COD / UPI / Card is a field recorded on the
  order — no money moves. Real payment needs a gateway account (Razorpay,
  Stripe, etc.) with your own API keys; I can wire that in once you have one.
- **No database.** Orders and their status live in each pod's memory. A pod
  restart or a scale-down wipes them. Good enough for a demo/portfolio
  project; a real system would put orders in DynamoDB or Postgres.
- **Redis is a single pod with no persistence.** If it restarts, no data is
  lost that matters (it's just a message bus here, not storage), but if you
  scale `notification-service` to more than 1 replica, Redis pub/sub still
  works correctly across replicas — that's actually the whole reason to use
  pub/sub instead of an in-memory array.
- **`:latest` + rollout restart** is a simple, learner-friendly deploy
  strategy. A production pipeline would tag images with the Jenkins build
  number and use `kubectl set image` so you always know exactly which build
  is running and can roll back precisely.

## 8. Project layout

```
ecommerce-microservices-demo/
├── README.md
├── Jenkinsfile
├── docker-compose.yml          # local testing, no k8s needed
├── k8s/
│   ├── namespace.yaml
│   ├── redis.yaml
│   ├── catalog-service.yaml
│   ├── cart-service.yaml
│   ├── order-service.yaml
│   ├── notification-service.yaml
│   └── gateway.yaml            # the only one with type: LoadBalancer
└── services/
    ├── catalog-service/
    ├── cart-service/
    ├── order-service/
    ├── notification-service/
    └── gateway/
        └── public/index.html   # the Ruchi frontend
```

Each service under `services/` is a complete, independent Node.js app with
its own `package.json` and `Dockerfile` — that's what makes it a
microservice rather than a folder inside one big app.
