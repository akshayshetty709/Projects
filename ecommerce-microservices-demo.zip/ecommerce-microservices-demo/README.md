# Ruchi — E-Commerce Microservices Demo (with realtime order tracking)

This is your Zomato-style food ordering app, rebuilt as **6 independent
microservices** — including a properly separated frontend — with **live
WebSocket order tracking** instead of polling. Same DevOps pipeline pattern
you already have working (Jenkins → Docker Hub → EKS) — just applied to 6
images instead of 1.

Read this top to bottom once before you deploy anything. It explains *why*
each piece exists, not just what to type.

---

## 1. Why microservices at all?

Your original project was one app doing everything: restaurants, menus,
orders, all in one `server.js`. That's fine for a demo, but it doesn't teach
or demonstrate the thing real companies use microservices for: **each part
can be built, deployed, scaled, and fixed independently.**

If `order-service` crashes, `catalog-service` keeps serving menus. If Diwali
traffic hits and everyone's browsing restaurants but not ordering, you scale
`catalog-service` to 5 replicas and leave the others at 1. If you're pushing
a UI tweak, you rebuild only `frontend` — every backend service keeps
running untouched. You cannot do any of that with one monolithic app.

## 2. The six services

The frontend is now its own service — not files sitting inside the
gateway. That matters: it means the UI has its own Dockerfile, its own
release cycle, and can be swapped for a completely different technology
(React, a CDN, whatever) without touching a single backend service.

```
   Browser ──────▶ ┌───────────┐        the ONLY public URL.
                    │ frontend  │        nginx: serves the UI, and reverse-
                    │  (nginx)  │        proxies /api/* and /socket.io/*
                    └─────┬─────┘        to the gateway below.
                          │
                          ▼
                   ┌─────────────┐       internal only (ClusterIP) —
                   │   gateway   │       the browser never talks to this
                   └──────┬──────┘       directly, only nginx does.
              ┌───────────┼────────────┬─────────────────┐
              ▼           ▼            ▼                 │
     /api/restaurants /api/orders  /socket.io             │
              │           │            │                  │
              ▼           ▼            ▼                  │
      ┌────────────┐ ┌──────────┐ ┌──────────────────┐    │
      │  catalog-  │ │  order-  │ │  notification-    │    │
      │  service   │ │ service  │ │  service          │    │
      └────────────┘ └────┬─────┘ └─────────┬──────────┘    │
             ▲             │ calls also        │
             │             ▼                   │
             │       ┌─────────────┐           │
             └───────┤ cart-service│           │
                      └─────────────┘           │
                             │ publishes          │ subscribes
                             ▼                    ▼
                       ┌───────────────────────────┐
                       │           Redis            │
                       │    (pub/sub message bus)   │
                       └───────────────────────────┘
```

| Service | Job | Talks to |
|---|---|---|
| **frontend** | The only public entry point. nginx container: serves the Ruchi UI as static files, reverse-proxies `/api/*` and `/socket.io/*` to the gateway (including WebSocket upgrade headers). | gateway |
| **gateway** | Internal API gateway. Routes `/api/restaurants` → catalog-service, `/api/orders` → order-service, `/socket.io` → notification-service. No longer serves any HTML. | catalog, order, notification |
| **catalog-service** | Owns restaurant + menu data. The only service that knows prices. | — |
| **cart-service** | Prices a cart. Looks up real prices from catalog-service instead of trusting the browser. | catalog-service |
| **order-service** | Creates orders, runs the delivery status lifecycle (placed → confirmed → preparing → out for delivery → delivered), publishes every status change to Redis. | cart-service, catalog-service, Redis |
| **notification-service** | Holds a live WebSocket connection with every browser tracking an order. Listens to Redis and pushes updates instantly. | Redis |
| **Redis** | The message bus. Not a database here — just the pipe that carries "order 7 just changed to preparing" from order-service to notification-service. | — |

**Request path for a page load:** browser → frontend (nginx) → gateway → catalog-service.
**Request path for a live status update:** order-service → Redis → notification-service → gateway (WS proxy) → frontend (WS proxy) → browser.

## 3. How "realtime" actually works here

This is the part worth understanding, not just copying.

Your old version used **polling**: the browser asked `GET /orders/:id` every
3 seconds, "any update? any update? any update?" — wasteful, and delayed by
up to 3 seconds.

The new version uses **push**:

1. Browser places an order, then opens a WebSocket to `notification-service`
   (through the gateway) and says "tell me about order #7."
2. `order-service`'s internal timer moves the order from `placed` to
   `confirmed`. The instant that happens, it publishes a message to Redis
   on the channel `order-status`.
3. `notification-service` is subscribed to that channel. The message
   arrives instantly and it forwards it to whichever browser sockets asked
   about order #7.
4. The browser's UI updates the same millisecond — no delay, no wasted
   requests.

This publish/subscribe pattern (Redis pub/sub) is a small version of what
companies do with Kafka or RabbitMQ at scale. Same idea, much simpler
plumbing — perfect for learning it.

## 4. Test it locally first (do this before touching Jenkins)

You need Docker + Docker Compose installed. From the project root:

```bash
docker compose up --build
```

Wait for all 7 containers to report healthy, then open **http://localhost:8080**
in a browser (not `:4000` — that's the internal gateway now; `:8080` is the
frontend, the actual public entry point). Browse restaurants, add items to cart, checkout, and watch the
order tracker move through stages live — this is the exact same code that
will run on EKS, just without Kubernetes in the way. If something's broken,
it's much faster to find out here than in a Jenkins log.

Stop it with `docker compose down` when you're done.

## 5. Deploying to EKS via Jenkins

You already have the Jenkins → Docker Hub → EKS pipeline working from the
previous project, so the credentials are already set up:

- `dockerhub-creds` (username/password) — reused as-is
- `kubeconfig-creds` (secret file) — reused as-is, must point at your
  current EKS cluster (the one you already fixed earlier)
- The IAM identity behind your kubeconfig must already have access to the
  cluster (you set this up with `create-access-entry` earlier)

**Steps:**

1. Push this whole folder to a new GitHub repo (or a new branch of your
   existing one).
2. In Jenkins, create a new Pipeline job pointing at it, same as before.
3. Run it. The `Jenkinsfile` does, in order:
   - Builds all 6 Docker images (5 Node services + the nginx frontend)
   - Pushes all 6 to Docker Hub under `<your-dockerhub-username>/ecommerce-<service>`
   - Replaces the `YOUR_DOCKERHUB_USERNAME` placeholder in the k8s manifests
     with your real Docker Hub username (using `sed`, automatically —
     you don't need to edit the YAML files by hand)
   - Applies the namespace, Redis, and all 6 service manifests to your
     cluster
   - Forces every deployment to pull the freshly-pushed `:latest` image
     (`kubectl rollout restart`) — this matters because Kubernetes doesn't
     automatically notice that `:latest` now points at something new

4. Once it finishes:
   ```bash
   kubectl -n ecommerce get pods
   kubectl -n ecommerce get svc frontend
   ```
   The `frontend` service is `type: LoadBalancer` — AWS will give it a
   public ELB address. `gateway` is deliberately `ClusterIP` (no public
   address) since the browser should never reach it directly. Open the
   `frontend` ELB address in a browser.

## 6. Verifying it's actually working end to end

```bash
kubectl -n ecommerce get pods
```
All pods should be `Running` with `READY 1/1`. If `order-service` or
`notification-service` are crash-looping, it's almost always because they
can't reach Redis — check:
```bash
kubectl -n ecommerce logs deployment/order-service
kubectl -n ecommerce get svc redis
```

Then in the browser: place an order and watch it move through
"Order placed → Confirmed → Preparing → Out for delivery → Delivered"
on its own, roughly every 6 seconds, without refreshing the page. That's
the realtime pipeline working.

## 7. Honest limitations (worth knowing, not hiding)

- **Payment is simulated.** COD / UPI / Card is a field recorded on the
  order — no money moves. Real payment needs a gateway account (Razorpay,
  Stripe, etc.) with your own API keys; I can wire that in once you have one.
- **No database.** Orders and their status live in each pod's memory. A pod
  restart or a scale-down wipes them. Good enough for a demo/portfolio
  project; a real system would put orders in DynamoDB or Postgres.
- **Redis is a single pod with no persistence.** If it restarts, no data is
  lost that matters (it's just a message bus here, not storage), but if you
  scale `notification-service` to more than 1 replica, Redis pub/sub still
  works correctly across replicas — that's actually the whole reason to use
  pub/sub instead of an in-memory array.
- **`:latest` + rollout restart** is a simple, learner-friendly deploy
  strategy. A production pipeline would tag images with the Jenkins build
  number and use `kubectl set image` so you always know exactly which build
  is running and can roll back precisely.

## 8. Project layout

```
ecommerce-microservices-demo/
├── README.md
├── Jenkinsfile
├── docker-compose.yml          # local testing, no k8s needed
├── k8s/
│   ├── namespace.yaml
│   ├── redis.yaml
│   ├── frontend.yaml           # type: LoadBalancer — the public one
│   ├── gateway.yaml            # type: ClusterIP — internal only
│   ├── catalog-service.yaml
│   ├── cart-service.yaml
│   ├── order-service.yaml
│   └── notification-service.yaml
└── services/
    ├── frontend/                # nginx — its own microservice, not files inside gateway
    │   ├── Dockerfile
    │   ├── nginx.conf
    │   └── public/index.html    # the Ruchi UI
    ├── gateway/                  # pure API gateway, no HTML
    ├── catalog-service/
    ├── cart-service/
    ├── order-service/
    └── notification-service/
```

Each folder under `services/` is a complete, independent app with its own
`Dockerfile` and its own release cycle — that's what makes this a real
frontend+backend microservices split rather than one app with folders.
`frontend` is nginx/static HTML; everything else is Node.js.
