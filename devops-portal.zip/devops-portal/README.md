# Signal — Real-Time DevOps Portal

A live-updating DevOps dashboard: service health, latency sparklines, and a
streaming event log, pushed to the browser over WebSockets (Socket.io). Same
Jenkins → Docker Hub → EKS flow as the earlier demo.

> The metrics/events are simulated in `backend/server.js` (`tick()`,
> every 2.5s) so the portal is live and demo-able with no other infra wired
> up. Swap that function for real calls to the Kubernetes API, Prometheus,
> or the Jenkins API to make it show your actual environment.

## Project layout

```
.
├── backend/
│   ├── server.js         # Express API + Socket.io + serves the built frontend
│   ├── server.test.js
│   └── package.json
├── frontend/               # React (Vite)
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   └── components/
│   │       ├── ServiceCard.jsx
│   │       ├── Pulse.jsx    # live canvas sparkline per service
│   │       └── EventLog.jsx # terminal-style live event tail
│   └── package.json
├── Dockerfile               # builds frontend, bundles into the backend image
├── Jenkinsfile
└── k8s/
    ├── namespace.yaml
    ├── deployment.yaml
    └── service.yaml         # ClientIP session affinity for sticky websockets
```

## One-time setup on your Jenkins server

Same as the API demo:

1. Plugins: `Pipeline`, `Docker Pipeline`, `Credentials Binding`,
   `Amazon Web Services SDK :: All` (or `pipeline-aws`).
2. Agent needs `docker`, `node`/`npm`, `kubectl`, `aws` CLI on `PATH`.
3. Credentials in Jenkins:
   - `dockerhub-creds` — Docker Hub username + access token.
   - `aws-eks-creds` — AWS credentials for a principal that can
     `eks:DescribeCluster` and deploy into the `devops-portal` namespace.
4. Edit the `TODO`s in `Jenkinsfile`: `DOCKERHUB_USER`, `EKS_CLUSTER_NAME`,
   `AWS_REGION`.
5. Point a Jenkins Pipeline job at this repo.

## What the pipeline does

1. Checkout.
2. **Backend**: `npm ci` + `npm test` (Jest/Supertest against the Express
   API).
3. **Frontend**: `npm install` + `npm run build` (Vite build — this isn't
   strictly required before the Docker stage since the Dockerfile rebuilds
   it too, but it fails the pipeline fast if the frontend doesn't compile).
4. **Docker Build** — a 3-stage build: compile the frontend, install backend
   deps, then a slim runtime image that serves both the static frontend and
   the API/WebSocket from one Express process on port 3000.
5. **Docker Push** to Docker Hub (`<user>/devops-portal:<build-number>` and
   `:latest`).
6. **Configure kubectl** via `aws eks update-kubeconfig`.
7. **Deploy to EKS** — applies the namespace/service, templates the new
   image tag into `deployment.yaml`, applies it, and waits on
   `kubectl rollout status`.

## Running locally

```bash
# terminal 1 — backend
cd backend
npm install
npm start            # http://localhost:3000 (API + socket)

# terminal 2 — frontend dev server (proxies /api and /socket.io to :3000)
cd frontend
npm install
npm run dev           # http://localhost:5173
```

Or build the single production image:

```bash
docker build -t devops-portal:local .
docker run -p 3000:3000 devops-portal:local
# open http://localhost:3000
```

## Verifying the deployment

```bash
kubectl get pods -n devops-portal
kubectl get svc devops-portal -n devops-portal   # EXTERNAL-IP is the ELB hostname
curl http://<EXTERNAL-IP>/health
```
Open `http://<EXTERNAL-IP>` in a browser — the service cards and event log
should update every couple of seconds.

## Notes for a real deployment

- **Scaling past 2 replicas**: Socket.io needs either sticky sessions (the
  Service already sets `sessionAffinity: ClientIP`) or a shared adapter
  (e.g. `@socket.io/redis-adapter`) if you want broadcasts to reach clients
  connected to *other* pods. For a dashboard where each pod independently
  simulates/fetches the same state, sticky sessions alone are enough.
- Replace the simulated `tick()` with real data sources: the Kubernetes API
  (via `@kubernetes/client-node`) for pod/deployment status, and the Jenkins
  REST API for build results.
- As before: prefer IRSA/OIDC over static AWS keys, consider an ALB Ingress
  with TLS instead of a bare LoadBalancer Service, and pin image digests for
  production.
