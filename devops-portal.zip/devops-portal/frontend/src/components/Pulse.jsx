import React, { useEffect, useRef } from 'react';

const COLORS = {
  healthy: '#3fb950',
  warn: '#d29922',
  critical: '#f85149',
};

// Renders a live ECG-style trace of latency history, color-coded by status.
export default function Pulse({ history, status, width = 220, height = 48 }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    if (history.length < 2) return;

    const max = Math.max(...history, 1);
    const min = Math.min(...history, 0);
    const range = Math.max(max - min, 1);
    const step = width / (history.length - 1);

    ctx.beginPath();
    ctx.lineWidth = 1.75;
    ctx.strokeStyle = COLORS[status] || COLORS.healthy;
    ctx.shadowColor = COLORS[status] || COLORS.healthy;
    ctx.shadowBlur = 6;

    history.forEach((v, i) => {
      const x = i * step;
      const y = height - 6 - ((v - min) / range) * (height - 12);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }, [history, status, width, height]);

  return <canvas ref={canvasRef} className="pulse-canvas" aria-hidden="true" />;
}
