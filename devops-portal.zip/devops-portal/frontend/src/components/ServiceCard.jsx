import React from 'react';
import Pulse from './Pulse.jsx';

const STATUS_LABEL = {
  healthy: 'Healthy',
  warn: 'Degraded',
  critical: 'Critical',
};

export default function ServiceCard({ service, history }) {
  return (
    <div className={`card status-${service.status}`}>
      <div className="card-top">
        <div>
          <div className="card-label">{service.label}</div>
          <div className={`card-status status-text-${service.status}`}>
            <span className="dot" />
            {STATUS_LABEL[service.status]}
          </div>
        </div>
        <div className="card-metric">
          <span className="metric-value">{service.latencyMs}</span>
          <span className="metric-unit">ms</span>
        </div>
      </div>

      <Pulse history={history} status={service.status} />

      <div className="card-foot">
        <span>{service.replicas} replicas</span>
        <span className="card-id">{service.id}</span>
      </div>
    </div>
  );
}
