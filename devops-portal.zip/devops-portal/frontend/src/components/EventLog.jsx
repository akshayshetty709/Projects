import React, { useEffect, useRef } from 'react';

export default function EventLog({ events }) {
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = 0;
  }, [events]);

  return (
    <div className="event-log">
      <div className="event-log-head">
        <span className="event-log-title">live events</span>
        <span className="event-log-caret">tail -f /var/log/portal.log</span>
      </div>
      <div className="event-log-body" ref={logRef}>
        {events.length === 0 && <div className="event-log-empty">waiting for events…</div>}
        {events.map((e) => (
          <div className="event-row" key={e.id}>
            <span className="event-time">{new Date(e.time).toLocaleTimeString()}</span>
            <span className="event-msg">{e.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
