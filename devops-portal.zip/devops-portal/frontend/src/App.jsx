import React, { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import ServiceCard from './components/ServiceCard.jsx';
import EventLog from './components/EventLog.jsx';
import './App.css';

const HISTORY_LEN = 24;

export default function App() {
  const [services, setServices] = useState([]);
  const [events, setEvents] = useState([]);
  const [connected, setConnected] = useState(false);
  const [now, setNow] = useState(new Date());
  const historyRef = useRef({});

  useEffect(() => {
    const socket = io({ path: '/socket.io' });

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    socket.on('services', (incoming) => {
      incoming.forEach((svc) => {
        const h = historyRef.current[svc.id] || [];
        historyRef.current[svc.id] = [...h, svc.latencyMs].slice(-HISTORY_LEN);
      });
      setServices(incoming);
    });

    socket.on('events-init', (initial) => setEvents(initial));
    socket.on('event', (evt) => setEvents((prev) => [evt, ...prev].slice(0, 30)));

    return () => socket.close();
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const overallStatus = services.some((s) => s.status === 'critical')
    ? 'critical'
    : services.some((s) => s.status === 'warn')
    ? 'warn'
    : 'healthy';

  return (
    <div className="portal">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">▮▮</span>
          <span className="brand-name">signal</span>
          <span className="brand-sub">devops portal</span>
        </div>
        <div className="topbar-right">
          <div className={`overall status-text-${overallStatus}`}>
            <span className="dot" />
            {services.length} services · {overallStatus}
          </div>
          <div className={`conn ${connected ? 'conn-on' : 'conn-off'}`}>
            <span className="dot" />
            {connected ? 'live' : 'reconnecting'}
          </div>
          <div className="clock">{now.toLocaleTimeString()}</div>
        </div>
      </header>

      <main className="grid">
        {services.map((svc) => (
          <ServiceCard key={svc.id} service={svc} history={historyRef.current[svc.id] || []} />
        ))}
      </main>

      <EventLog events={events} />
    </div>
  );
}
