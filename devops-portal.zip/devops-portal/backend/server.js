const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

// ---- In-memory "state of the world" for the demo ----
const services = [
  { id: 'checkout-api', label: 'checkout-api', status: 'healthy', replicas: 3, latencyMs: 42 },
  { id: 'payments-api', label: 'payments-api', status: 'healthy', replicas: 3, latencyMs: 58 },
  { id: 'catalog-api', label: 'catalog-api', status: 'warn', replicas: 2, latencyMs: 145 },
  { id: 'auth-service', label: 'auth-service', status: 'healthy', replicas: 4, latencyMs: 31 },
  { id: 'notification-worker', label: 'notification-worker', status: 'healthy', replicas: 2, latencyMs: 20 },
  { id: 'search-index', label: 'search-index', status: 'healthy', replicas: 3, latencyMs: 77 },
];

const eventTemplates = [
  (s) => `Build #${100 + Math.floor(Math.random() * 900)} passed for ${s}`,
  (s) => `Rolling update started for ${s}`,
  (s) => `Pod restarted: ${s}-${Math.floor(Math.random() * 9000)}`,
  (s) => `Deployed ${s} to production`,
  (s) => `Health check recovered for ${s}`,
  (s) => `Autoscaler added a replica to ${s}`,
];

let events = [];

function randomStatus(current) {
  const roll = Math.random();
  if (roll < 0.85) return current;
  const options = ['healthy', 'warn', 'critical'];
  return options[Math.floor(Math.random() * options.length)];
}

function tick() {
  services.forEach((svc) => {
    svc.status = randomStatus(svc.status);
    svc.latencyMs = Math.max(8, Math.round(svc.latencyMs + (Math.random() - 0.5) * 30));
  });

  if (Math.random() < 0.6) {
    const svc = services[Math.floor(Math.random() * services.length)];
    const template = eventTemplates[Math.floor(Math.random() * eventTemplates.length)];
    const event = {
      id: Date.now(),
      time: new Date().toISOString(),
      message: template(svc.label),
    };
    events.unshift(event);
    events = events.slice(0, 30);
    io.emit('event', event);
  }

  io.emit('services', services);
}

setInterval(tick, 2500);

// ---- REST API (also usable without the socket) ----
app.get('/api/services', (req, res) => res.json(services));
app.get('/api/events', (req, res) => res.json(events));
app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }));

io.on('connection', (socket) => {
  socket.emit('services', services);
  socket.emit('events-init', events);
});

// ---- Serve the built React app ----
const staticDir = path.join(__dirname, 'public');
app.use(express.static(staticDir));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path === '/health') return next();
  res.sendFile(path.join(staticDir, 'index.html'));
});

if (require.main === module) {
  server.listen(PORT, () => console.log(`devops-portal listening on ${PORT}`));
}

module.exports = { app, server };
